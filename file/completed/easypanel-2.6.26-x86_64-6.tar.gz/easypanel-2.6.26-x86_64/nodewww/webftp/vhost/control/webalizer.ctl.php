<?php
needRole('vhost');
class WebalizerControl extends control
{
	public function showLog()
	{
		exit('not suppor');
	}
}

?>