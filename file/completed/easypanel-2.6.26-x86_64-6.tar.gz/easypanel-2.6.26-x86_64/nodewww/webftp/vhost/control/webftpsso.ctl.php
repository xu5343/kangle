<?php
class WebftpssoControl extends Control
{}

?>