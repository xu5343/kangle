<?php
class FileaccessAPI extends API
{
	public function add($vhost, $file, $action)
	{
	}

	public function del($vhost, $file)
	{
	}

	private function convert($vhost)
	{
	}

	private function init($vhost)
	{
	}
}

?>