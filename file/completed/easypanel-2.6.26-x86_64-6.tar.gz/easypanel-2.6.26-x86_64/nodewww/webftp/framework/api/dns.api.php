<?php
class DnsAPI extends API
{}

?>