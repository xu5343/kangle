<?php
function get_lang()
{
	return array('myinfo' => '我的信息', 'account_manage' => '账号管理', 'change_passwd' => '修改密码', 'product_id' => '产品ID', 'TOMCAT_PASSWD' => 'tomcat密码', 'ZEND' => 'zend', 'ON' => '开', 'OFF' => '关', '' => '');
}


?>