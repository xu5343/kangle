<?php
class Model
{
	public function __construct()
	{
	}

	public function __destruct()
	{
	}

	public function index()
	{
	}
}


?>