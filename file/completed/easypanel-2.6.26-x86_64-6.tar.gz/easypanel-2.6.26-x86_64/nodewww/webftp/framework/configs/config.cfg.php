<?php
$max_index_count = 100;

?>