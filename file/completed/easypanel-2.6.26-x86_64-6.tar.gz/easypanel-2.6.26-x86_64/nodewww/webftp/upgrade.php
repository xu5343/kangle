<?php
header('Location: admin/?c=session&a=upgrade');

?>