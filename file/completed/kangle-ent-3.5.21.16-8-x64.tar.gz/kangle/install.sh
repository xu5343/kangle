#!/bin/sh
if test $# != 1;then
        echo "Usage: ./install.sh dir"
        exit 1;
fi
PREFIX=$1
CONFIG="/etc/config.xml /etc/vh.xml /etc/mime.types.xml /www/index.html"
echo "try stop kangle..."
#stop kangle
KANGLE_QUIT_RET=1
if [ -f $PREFIX/bin/kangle ]; then
        $PREFIX/bin/kangle -q
        KANGLE_QUIT_RET=$?
fi
echo "now installing kangle to $PREFIX"
mkdir -p $PREFIX
restore_config()
{
        for p in $CONFIG; do
        if test -f $PREFIX$p.bak; then
                mv $PREFIX$p.bak $PREFIX$p
                if test $? != 0; then
                        echo "cann't restore config file $PREFIX$p"
                        exit 1
                fi

        fi
        done

}
#backup config file
for p in $CONFIG; do
        if test -f $PREFIX$p; then
                cp $PREFIX$p $PREFIX$p.bak
                if test $? != 0; then
                        echo "cann't create config file $PREFIX$p.bak to backup"
                        exit 1
                fi
        fi
done
echo "now copying file to $PREFIX"
chmod 700 etc
cp . $PREFIX/ -prf
if test $? != 0; then
        echo "cann't copy file to $PREFIX. Please check right."
        restore_config
        exit 1;
fi
restore_config
#start kangle
if [ $KANGLE_QUIT_RET = 0 ] ; then
        $PREFIX/bin/kangle --reboot
fi
echo "success install to $PREFIX"
